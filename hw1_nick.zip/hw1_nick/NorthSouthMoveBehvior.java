import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.util.LinkedList;
import java.util.List;
import javax.swing.Icon;

public class NorthSouthMoveBehavior extends MoveBehvior {
    public void move(Canavs c, Sprite s) {
        switch (s.getDirection()) {
          case NORTH:
            s.setY(s.getY() - 10);
            if (s.getY() < 0) {
              s.setY(0);
              s.setDirection(Sprite.Direction.SOUTH);
            }
            break;
          case SOUTH:
            s.setY(s.getY() + 10);
            Icon icon = s.getCurrentImage();
            if (s.getY() + icon.getIconHeight() > c.getSize().getHeight()) {
              s.setY((int)(c.getSize().getHeight() - icon.getIconHeight()));
              s.setDirection(Sprite.Direction.NORTH);
            }
            break;
        }
    }
}
