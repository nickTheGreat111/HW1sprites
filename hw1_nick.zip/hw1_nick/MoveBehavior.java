import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.util.LinkedList;
import java.util.List;
import javax.swing.Icon;

public abstract class MoveBehavior {
    public abstact void move(Canavs c, Sprite s);
}
